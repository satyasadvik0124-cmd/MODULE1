import os
import yfinance as yf

project_folder = "/content/drive/MyDrive/market_ml_project-20260815T095833Z-1-001/market_ml_project"

symbols = {
    "NIFTY": "^NSEI",
    "BANKNIFTY": "^NSEBANK",
    "SENSEX": "^BSESN"
}

os.makedirs(project_folder, exist_ok=True)

for name, symbol in symbols.items():

    print("\n" + "=" * 60)
    print(f"Downloading {name}")
    print("=" * 60)

    df = yf.download(
        symbol,
        start="2008-01-01",
        auto_adjust=True,
        progress=False
    )

    if df.empty:
        print(f"ERROR: No data downloaded for {name}")
        continue

    if df.columns.nlevels > 1:
        df.columns = df.columns.get_level_values(0)

    df.index.name = "Date"

    filepath = os.path.join(
        project_folder,
        f"{name.lower()}_daily.csv"
    )

    df.to_csv(filepath)

    print(f"{name} saved successfully.")
    print(f"Rows: {len(df)}")
    print(f"Latest date: {df.index.max()}")
    print(f"Saved to: {filepath}")

print("\n" + "=" * 60)
print("MARKET DATA UPDATE COMPLETED")
print("=" * 60)
