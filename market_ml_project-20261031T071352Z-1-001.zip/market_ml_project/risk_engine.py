import os
import glob
import pickle
import warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

POSSIBLE_DIRS = [
    "/content/drive/MyDrive/market_ml_project-20260815T095833Z-1-001/market_ml_project",
    "/content/market_ml_project",
    "/content/drive/MyDrive/market_ml_project"
]

BASE_DIR = None

for path in POSSIBLE_DIRS:
    if os.path.exists(path):
        BASE_DIR = path
        break

if BASE_DIR is None:
    matches = glob.glob(
        "/content/drive/MyDrive/**/market_ml_project",
        recursive=True
    )
    if len(matches) > 0:
        BASE_DIR = matches[0]

if BASE_DIR is None:
    raise FileNotFoundError(
        "Could not find market_ml_project directory."
    )

print("Project directory:")
print(BASE_DIR)

INPUT_FILE = os.path.join(
    BASE_DIR,
    "sensex_weekly_features.csv"
)

SENTIMENT_FILE = os.path.join(
    BASE_DIR,
    "gdelt_weekly_sentiment.pkl"
)

OUTPUT_FILE = os.path.join(
    BASE_DIR,
    "sensex_risk_engine_v2.csv"
)

if not os.path.exists(INPUT_FILE):
    raise FileNotFoundError(
        f"Market dataset not found:\n{INPUT_FILE}"
    )

print("\nLoading market data...")

df = pd.read_csv(INPUT_FILE)

print("Rows:", len(df))
print("Columns:", len(df.columns))

if "Date" not in df.columns:
    raise ValueError("Date column not found.")

df["Date"] = pd.to_datetime(
    df["Date"],
    errors="coerce"
)

try:
    df["Date"] = df["Date"].dt.tz_localize(None)
except:
    pass

df = df.dropna(subset=["Date"])
df = df.sort_values("Date").reset_index(drop=True)

required_columns = [
    "Close",
    "High",
    "Low",
    "Volume",
    "ema_20",
    "ema_50",
    "ema_100",
    "rsi_14",
    "macd",
    "macd_signal",
    "macd_hist"
]

missing_columns = [
    col for col in required_columns
    if col not in df.columns
]

if missing_columns:
    raise ValueError(
        "Missing required columns: "
        + str(missing_columns)
    )

print("\nCalculating risk features...")

df["ema20_vs_ema50"] = (
    df["ema_20"] / df["ema_50"] - 1
)

df["ema50_vs_ema100"] = (
    df["ema_50"] / df["ema_100"] - 1
)

df["rsi14"] = df["rsi_14"]

df["rsi_distance_50"] = (
    df["rsi14"] - 50
)

df["weekly_return"] = (
    df["Close"].pct_change()
)

df["realized_vol_4w"] = (
    df["weekly_return"]
    .rolling(4)
    .std()
    * np.sqrt(4)
)

df["realized_vol_8w"] = (
    df["weekly_return"]
    .rolling(8)
    .std()
    * np.sqrt(8)
)

df["realized_vol_20w"] = (
    df["weekly_return"]
    .rolling(20)
    .std()
    * np.sqrt(20)
)

df["vol_ratio"] = (
    df["realized_vol_8w"]
    / df["realized_vol_20w"]
)

rolling_max_20 = (
    df["Close"]
    .rolling(20)
    .max()
)

df["drawdown_20w"] = (
    df["Close"] / rolling_max_20 - 1
)

rolling_max_52 = (
    df["Close"]
    .rolling(52)
    .max()
)

df["drawdown_52w"] = (
    df["Close"] / rolling_max_52 - 1
)

print("Risk features created successfully.")

print("\nLoading GDELT sentiment...")

df["mean_sentiment"] = np.nan
df["median_sentiment"] = np.nan
df["sentiment_std"] = np.nan
df["news_count"] = np.nan

if os.path.exists(SENTIMENT_FILE):

    try:
        with open(SENTIMENT_FILE, "rb") as f:
            sentiment = pickle.load(f)

        sentiment = pd.DataFrame(sentiment)

        print("Sentiment rows:", len(sentiment))
        print(
            "Sentiment columns:",
            list(sentiment.columns)
        )

        if "week" in sentiment.columns:
            sentiment["Date"] = pd.to_datetime(
                sentiment["week"],
                errors="coerce",
                utc=True
            )
        elif "Date" in sentiment.columns:
            sentiment["Date"] = pd.to_datetime(
                sentiment["Date"],
                errors="coerce",
                utc=True
            )
        else:
            raise ValueError(
                "GDELT file does not contain week or Date."
            )

        sentiment["Date"] = (
            sentiment["Date"].dt.tz_localize(None)
        )

        sentiment = sentiment.dropna(
            subset=["Date"]
        )

        sentiment = (
            sentiment
            .sort_values("Date")
            .reset_index(drop=True)
        )

        if "mean_sentiment" not in sentiment.columns:
            raise ValueError(
                "mean_sentiment column not found."
            )

        keep_columns = [
            "Date",
            "mean_sentiment"
        ]

        for column in [
            "median_sentiment",
            "sentiment_std",
            "news_count"
        ]:
            if column in sentiment.columns:
                keep_columns.append(column)

        sentiment = sentiment[keep_columns]

        sentiment = (
            sentiment
            .drop_duplicates(
                subset=["Date"],
                keep="last"
            )
            .sort_values("Date")
        )

        df["Date"] = pd.to_datetime(
            df["Date"],
            errors="coerce"
        )

        try:
            df["Date"] = (
                df["Date"].dt.tz_localize(None)
            )
        except:
            pass

        df = (
            df
            .dropna(subset=["Date"])
            .sort_values("Date")
            .reset_index(drop=True)
        )

        df = pd.merge_asof(
            df,
            sentiment,
            on="Date",
            direction="backward",
            suffixes=("", "_gdelt")
        )

        for column in [
            "mean_sentiment",
            "median_sentiment",
            "sentiment_std",
            "news_count"
        ]:
            gdelt_column = column + "_gdelt"

            if gdelt_column in df.columns:
                df[column] = df[gdelt_column]
                df.drop(
                    columns=[gdelt_column],
                    inplace=True
                )

        print("GDELT sentiment merged successfully.")

    except Exception as e:
        print("WARNING: Could not load GDELT sentiment.")
        print("Reason:", str(e))

else:
    print("WARNING: GDELT sentiment file not found.")

def calculate_risk(row):

    score = 0
    reasons = []

    if (
        pd.notna(row["vol_ratio"])
        and row["vol_ratio"] > 1.25
    ):
        score += 20
        reasons.append("High volatility")

    if (
        pd.notna(row["drawdown_20w"])
        and row["drawdown_20w"] <= -0.05
    ):
        score += 20
        reasons.append("High drawdown")

    if (
        pd.notna(row["ema20_vs_ema50"])
        and row["ema20_vs_ema50"] < 0
    ):
        score += 20
        reasons.append("Bearish EMA trend")

    if (
        pd.notna(row["rsi14"])
        and row["rsi14"] < 40
    ):
        score += 15
        reasons.append("Weak RSI")

    if (
        pd.notna(row["macd_hist"])
        and row["macd_hist"] < 0
    ):
        score += 10
        reasons.append("Bearish MACD")

    if (
        pd.notna(row["mean_sentiment"])
        and row["mean_sentiment"] <= -0.20
    ):
        score += 15
        reasons.append("Negative news sentiment")

    if score <= 30:
        risk_level = "Low Risk"
    elif score <= 60:
        risk_level = "Moderate Risk"
    else:
        risk_level = "High Risk"

    if len(reasons) == 0:
        reason_text = "No major risk conditions detected"
    else:
        reason_text = "; ".join(reasons)

    return pd.Series([
        score,
        risk_level,
        reason_text
    ])

risk_results = df.apply(
    calculate_risk,
    axis=1
)

risk_results.columns = [
    "risk_score",
    "risk_level",
    "risk_reasons"
]

df = pd.concat(
    [df, risk_results],
    axis=1
)

INVESTOR_RISK_THRESHOLD = 50

df["investor_risk_threshold"] = (
    INVESTOR_RISK_THRESHOLD
)

df["risk_decision"] = np.where(
    df["risk_score"] > INVESTOR_RISK_THRESHOLD,
    "Risk Exceeds Tolerance",
    "Risk Within Tolerance"
)

valid_features = [
    "ema20_vs_ema50",
    "rsi14",
    "vol_ratio",
    "drawdown_20w",
    "macd_hist",
    "risk_score"
]

valid_df = df.dropna(
    subset=valid_features
).copy()

print(
    "\nValid rows with complete risk features:",
    len(valid_df)
)

print("\n" + "=" * 60)
print("RISK ENGINE STATISTICS")
print("=" * 60)

print(
    "Investor Risk Threshold:",
    INVESTOR_RISK_THRESHOLD
)

print(
    "Average Risk Score:",
    round(
        valid_df["risk_score"].mean(),
        2
    )
)

print(
    "Minimum Risk Score:",
    int(valid_df["risk_score"].min())
)

print(
    "Maximum Risk Score:",
    int(valid_df["risk_score"].max())
)

print("\nRisk Level Distribution:")
print(valid_df["risk_level"].value_counts())

print("\nRisk Condition Frequency:")

conditions = [
    "High volatility",
    "High drawdown",
    "Bearish EMA trend",
    "Weak RSI",
    "Bearish MACD",
    "Negative news sentiment"
]

for condition in conditions:

    count = (
        valid_df["risk_reasons"]
        .str.contains(
            condition,
            regex=False,
            na=False
        )
        .sum()
    )

    print(
        condition + ":",
        count
    )

latest = valid_df.iloc[-1]

print("\n" + "=" * 60)
print("LATEST RISK ASSESSMENT")
print("=" * 60)

print(
    "Date:",
    latest["Date"].strftime("%Y-%m-%d")
)

print(
    "Risk Score:",
    int(latest["risk_score"])
)

print(
    "Risk Level:",
    latest["risk_level"]
)

print(
    "Investor Threshold:",
    int(latest["investor_risk_threshold"])
)

print(
    "Decision:",
    latest["risk_decision"]
)

print(
    "EMA20 vs EMA50:",
    round(
        latest["ema20_vs_ema50"],
        4
    )
)

print(
    "RSI:",
    round(
        latest["rsi14"],
        2
    )
)

print(
    "8-week volatility:",
    round(
        latest["realized_vol_8w"] * 100,
        2
    ),
    "%"
)

print(
    "20-week volatility:",
    round(
        latest["realized_vol_20w"] * 100,
        2
    ),
    "%"
)

print(
    "Volatility ratio:",
    round(
        latest["vol_ratio"],
        4
    )
)

print(
    "20-week drawdown:",
    round(
        latest["drawdown_20w"] * 100,
        2
    ),
    "%"
)

print(
    "MACD histogram:",
    round(
        latest["macd_hist"],
        4
    )
)

if pd.notna(latest["mean_sentiment"]):
    print(
        "News sentiment:",
        round(
            latest["mean_sentiment"],
            4
        )
    )
else:
    print(
        "News sentiment:",
        "Not Available"
    )

print(
    "Risk reasons:",
    latest["risk_reasons"]
)

df.to_csv(
    OUTPUT_FILE,
    index=False
)

print("\n" + "=" * 60)
print("OUTPUT SAVED")
print("=" * 60)

print(OUTPUT_FILE)

print("\nRisk Engine V2 completed successfully.")
